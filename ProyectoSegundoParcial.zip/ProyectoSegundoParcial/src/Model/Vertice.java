package Model;

/**
 *ProyectoSegundoParcial
 * Programa que hace un grafo
 * 29 de julio de 2020
 * @author Giselle Medina
 * Versión 1.0
 */

public class Vertice {
    private int dato;
    private Vertice siguienteVertice;
    private Edge aristaAdyacente;
    String aristas="";
    
    public Vertice() {
        this.dato = 0;
        this.siguienteVertice = null;
        this.aristaAdyacente = null;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public Vertice getSiguienteVertice() {
        return siguienteVertice;
    }

    public void setSiguienteVertice(Vertice siguienteVertice) {
        this.siguienteVertice = siguienteVertice;
    }

    public Edge getAristaAdyacente() {
        return aristaAdyacente;
    }

    public void setAristaAdyacente(Edge aristaAdyacente) {
        this.aristaAdyacente = aristaAdyacente;
    }
    
     public String getAristas(){
        return aristas;
    }
    
    public void setAristas(String aristas){
        this.aristas=aristas;
    }
    
}
