package Model;

/**
 *ProyectoSegundoParcial
 * Programa que hace un grafo
 * 29 de julio de 2020
 * @author Giselle Medina
 * Versión 1.0
 */

public class Edge {
    private Vertice verticeDestino;
    private Edge siguienteArista;

    public Edge(Vertice verticeDestino) {
        this.verticeDestino = verticeDestino;
        this.siguienteArista = null;
    }

    public Vertice getVerticeDestino() {
        return verticeDestino;
    }

    public void setVerticeDestino(Vertice verticeDestino) {
        this.verticeDestino = verticeDestino;
    }

    public Edge getSiguienteArista() {
        return siguienteArista;
    }

    public void setSiguienteArista(Edge siguienteArista) {
        this.siguienteArista = siguienteArista;
    }
}
