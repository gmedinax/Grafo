package Model;

import javax.swing.JOptionPane;

/**
 *ProyectoSegundoParcial
 * Programa que hace un grafo
 * 29 de julio de 2020
 * @author Giselle Medina
 * Versión 1.0
 */

public class Graph {
      public Vertice inicio;
    public Vertice actual;
    
    //Constructor
     public Graph() {
        this.inicio = null;
    }

    public Vertice getInicio() {
        return inicio;
    }

    public void setInicio(Vertice inicio) {
        this.inicio = inicio;
    }

    /**
     * Nombre de la función: vacio
     * Descripción: Comprueba si hay 
     * algún grafo ingresado
     * @return boolean
     */
    
    public boolean vacio(){
        if(this.inicio==null){
         return true;
      }else{
            return false;
        }
    }
    
    /**
     * Nombre de la función: insertarVertice
     * Descripción: función que inserta 
     * vértices al grafo 
     * @param data 
     */
    
    public void insertarVertice(int data){
        if(vacio()==true){
            Vertice nuevo=new Vertice();
            nuevo.setDato(data);
            setInicio(nuevo);
        }else{
            Vertice nuevo=new Vertice();
            nuevo.setDato(data);
            Vertice aux=getInicio();
            while(aux.getSiguienteVertice()!=null){
                aux=aux.getSiguienteVertice();
            }
            aux.setSiguienteVertice(nuevo);
        }
    }
    
    /**
     * Nombre de la función: insertarArista
     * Descripción: función que inserta aristas
     * al grafo
     * @param origen
     * @param destino 
     */

    public void insertarArista(int origen, int destino){
        Vertice origin, destiny;
        origin=buscarVertice(origen);
        destiny=buscarVertice(destino);
        if(origin==null||destiny==null){
            JOptionPane.showMessageDialog(null,"No se puede insertar la arista");
        } else{
            //origin.setAristaAdyacente marca el inicio de la lista de aristas
            Edge nuevaArista = new Edge(destiny);
            if(origin.getAristaAdyacente()==null){
                origin.setAristaAdyacente(nuevaArista);
            } else{
                Edge aux=origin.getAristaAdyacente();
                while(aux.getSiguienteArista()!=null){
                    aux=aux.getSiguienteArista();
                }
                aux.setSiguienteArista(nuevaArista);
            }
            JOptionPane.showMessageDialog(null,"¡La arista ha sido añadida con éxito!");
        }
        
    }
    
    /**
     * Nombre de la función: buscarVertice
     * Descripción: función que recibe un 
     * valor (d) y busca ese valor en el grafo
     * @param d
     * @return vertice
     */
    public Vertice buscarVertice(int d){
        Vertice actual = this.inicio;
        if(vacio()==true){
            return null;
            
        } else{
            while(actual!=null && actual.getDato()!=d){
                actual=actual.getSiguienteVertice();
            }
            return actual;
        }
    }
    
    /**
     * Nombre de la función: mostrarVertice
     * Descripción: función que muestra los 
     * vértices en el grafo
     * @return vertice
     */
  
     public Vertice mostrarVertice(){
        Vertice auxiliar=new Vertice();
        auxiliar=actual;
        if(vacio()){
            JOptionPane.showMessageDialog(null,"No hay vertices");
        }else{
            if(auxiliar!=null){
                auxiliar.getDato();
            }
        }
        this.actual=auxiliar.getSiguienteVertice();
        return auxiliar;
     }
     
     /**
      * Nombre de la función: mostrarListaAdyacencia
      * Descripción: función que muestra la relación 
      * entre los vértices del grafo
      * @return 
      */
     
      public Vertice mostrarListaAdyacencia(){
        Vertice verticeActual=new Vertice();
        verticeActual=actual;
        if(vacio()){
             JOptionPane.showMessageDialog(null,"No hay ningun vertice");
        }else{
            if(verticeActual!=null){
                verticeActual.getDato();
               
                //Inicia recorrido de aristas
                Edge aristaActual=verticeActual.getAristaAdyacente();
                
                  while(aristaActual!=null){
                    verticeActual.setAristas(verticeActual.aristas+aristaActual.getVerticeDestino().getDato()+"->");
                    aristaActual=aristaActual.getSiguienteArista();
                }
            }
        }
        this.actual=verticeActual.getSiguienteVertice();
        return verticeActual;
    }
}
