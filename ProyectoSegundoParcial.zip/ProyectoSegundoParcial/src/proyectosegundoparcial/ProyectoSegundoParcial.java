package proyectosegundoparcial;

/**
 *ProyectoSegundoParcial
 * Programa que hace un grafo
 * 29 de julio de 2020
 * @author Giselle Medina
 * Versión 1.0
 */
import View.MainView;
import Controller.Controller;
import Model.Graph;

public class ProyectoSegundoParcial {
    public static void main(String[] args) {
        Graph theModel=new Graph();
        MainView theView = new MainView();
        Controller theController = new Controller(theView, theModel);
        theView.setVisible(true);
        theController.iniciar();
    }
    
}
