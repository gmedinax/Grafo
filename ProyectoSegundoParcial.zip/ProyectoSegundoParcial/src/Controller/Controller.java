package Controller;

/**
 *ProyectoSegundoParcial
 * Programa que hace un grafo
 * 29 de julio de 2020
 * @author Giselle Medina
 * Versión 1.0
 */

import Model.Edge;
import Model.Graph;
import Model.Vertice;
import View.MainView;
import View.ShowGraphView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Controller implements ActionListener, KeyListener{
      private Graph grafo = new Graph();
    private Vertice vertice=new Vertice();
    private Vertice auxV;
    private Edge arista = new Edge(vertice);
    private MainView vistitaPrincipal=new MainView();
    private ShowGraphView vistaTablitas;
    private DefaultTableModel tablitaVertice;
    private DefaultTableModel tablitaListaAdyacente;
    private int origin,destiny;
    
    
    //Constructor
    public Controller(MainView Vistita, Graph Grafo) {
        this.vistaTablitas = new ShowGraphView();
        this.vistitaPrincipal = Vistita;
        this.vistitaPrincipal.setVisible(true);
        this.grafo = Grafo;
        this.vistitaPrincipal.bttnAdd.addActionListener(this);
        this.vistitaPrincipal.bttnAddV.addActionListener(this);
        this.vistitaPrincipal.bttnAddO.addActionListener(this);
        this.vistitaPrincipal.bttnAddE.addActionListener(this);
        this.vistitaPrincipal.bttnSearch.addActionListener(this);
        this.vistitaPrincipal.bttnSearchV.addActionListener(this);
        this.vistitaPrincipal.bttnShowAL.addActionListener(this);
        this.vistitaPrincipal.bttnShowV.addActionListener(this);
        this.vistaTablitas.bttnHome.addActionListener(this);
        this.vistitaPrincipal.txtFldData.addKeyListener(this);
        this.vistitaPrincipal.txtFldOV.addKeyListener(this);
        this.vistitaPrincipal.txtFldDV.addKeyListener(this);
        this.vistitaPrincipal.txtFldSearchV.addKeyListener(this);
    }
    
    /**
     * Nombre de la función: iniciar
     * Descripción: función para inicializar 
     * el programa con ciertos ajustes.
     */
    public void iniciar(){
       this.vistitaPrincipal.setVisible(true);
        this.vistitaPrincipal.setTitle("Grafo");
        this.vistitaPrincipal.setSize(290,300);
        this.vistitaPrincipal.setResizable(false);
        this.vistitaPrincipal.setLocationRelativeTo(null);
        this.vistaTablitas.setLocationRelativeTo(null);
        this.vistaTablitas.setVisible(false);
        this.vistitaPrincipal.pnlAddV.setVisible(false);
        this.vistitaPrincipal.pnlAddEdge.setVisible(false);
        this.vistitaPrincipal.pnlSearchV.setVisible(false);
        this.vistaTablitas.pnlV.setVisible(false);
        this.vistaTablitas.pnlAL.setVisible(false);
    }
    
    /**
     * Nombre de la función: llenarVertice
     * Descripción: función que llena el 
     * grafo con vértices y crea una tabla 
     * para que esta muestre los vértices del grafo.
     */
    public void llenarVertice(){
        String []data= new String[1];
        tablitaVertice=new DefaultTableModel();
        this.tablitaVertice.addColumn("Vertice");
        while(this.grafo.actual!=null){
            this.vertice=this.grafo.mostrarVertice();
            data[0]=String.valueOf(this.vertice.getDato());
            this.tablitaVertice.addRow(data);
            vistaTablitas.tblVertice.setModel(tablitaVertice);
        }                        
    }
    
    /**
     * Nombre de la función: llenarLista
     * Descripción: función que llena la 
     * lista de adyacencia y crea una tabla 
     * para que esta muestre la relación del grafo.
     */ 
    public void llenarLista(){
        String []lista= new String [2];
        tablitaListaAdyacente=new DefaultTableModel();
        this.tablitaListaAdyacente.addColumn("Vertice origen");
        this.tablitaListaAdyacente.addColumn("Vertice destino");
        while(this.grafo.actual!=null){
            vertice.setAristas("");
            this.vertice=this.grafo.mostrarListaAdyacencia();
            lista[0]=String.valueOf(vertice.getDato());
            lista[1]=String.valueOf(vertice.getAristas());
            this.tablitaListaAdyacente.addRow(lista);
            vistaTablitas.tblAL.setModel(tablitaListaAdyacente);
        }
    }
    
    /**
     * Nombre de la función: limpiar
     * Descripción: función que establece 
     * los text fields en limpio.
     */
    public void limpiar(){
        this.vistitaPrincipal.txtFldData.setText("");
        this.vistitaPrincipal.txtFldOV.setText("");
        this.vistitaPrincipal.txtFldDV.setText("");
        this.vistitaPrincipal.txtFldSearchV.setText("");
        this.vistitaPrincipal.setTitle("Grafo");
        this.vistitaPrincipal.setSize(290,300);
        this.vistitaPrincipal.pnlAddV.setVisible(false);
        this.vistitaPrincipal.pnlSearchV.setVisible(false);
        this.vistitaPrincipal.pnlAddEdge.setVisible(false);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        try{
            String botoncito=e.getActionCommand();
            switch(botoncito){
                case "AddVertice":
                    this.vistitaPrincipal.setSize(455,300);
                    this.vistitaPrincipal.setTitle("Añadir vértice");
                    this.vistitaPrincipal.pnlAddV.setVisible(true);
                    this.vistitaPrincipal.pnlSearchV.setVisible(false);
                    this.vistitaPrincipal.pnlAddEdge.setVisible(false);
                    break;
                case "AddV":
                    this.grafo.inicio=this.grafo.getInicio();
                    try{
                        int verticeAux=Integer.parseInt(this.vistitaPrincipal.txtFldData.getText());
                        if(!this.vistitaPrincipal.txtFldData.getText().isEmpty()){
                            try{
                                this.grafo.insertarVertice(verticeAux);
                             
                                JOptionPane.showMessageDialog(null,"¡El vértice ha sido añadido con éxito!");
                            }catch(Exception ex){
                                JOptionPane.showMessageDialog(null,"¡Error! No se ha podido realizar la acción");
                            }
                        }else {
                        JOptionPane.showMessageDialog(null,"Ingresar información del vértice");
                        }
                    }catch(Exception x){
                        JOptionPane.showMessageDialog(null, "El vértice no ha sido añadido. \nIntente de nuevo más tarde.");
                    }
                    limpiar();
                    break;
                case "AddEdge":
                    this.vistitaPrincipal.setSize(290,470);
                    this.vistitaPrincipal.setTitle("Añadir arista");
                    this.vistitaPrincipal.pnlAddV.setVisible(false);
                    this.vistitaPrincipal.pnlAddEdge.setVisible(true);
                    this.vistitaPrincipal.pnlSearchV.setVisible(false);
                    break;
                case "AddE":
                    if(!this.vistitaPrincipal.txtFldOV.getText().isEmpty() && 
                            !this.vistitaPrincipal.txtFldDV.getText().isEmpty()){
                        int dest=Integer.parseInt(this.vistitaPrincipal.txtFldDV.getText());
                        int ori=Integer.parseInt(this.vistitaPrincipal.txtFldOV.getText());
                        try{
                            this.grafo.insertarArista(ori,dest);         
                                    
                            
                        }catch(Exception x){
                        JOptionPane.showMessageDialog(null, "La arista no ha sido añadida. \nIntente de nuevo más tarde.");
                        }
                    }else {
                        JOptionPane.showMessageDialog(null,"Ingresar información de la arista");
                    }
                     limpiar();
                     break;
                case "SearchVertice":
                    this.vistitaPrincipal.setSize(475,450);
                    this.vistitaPrincipal.setTitle("Buscar vértice");
                    this.vistitaPrincipal.pnlSearchV.setVisible(true);
                    this.vistitaPrincipal.pnlAddV.setVisible(false);
                    this.vistitaPrincipal.pnlAddEdge.setVisible(false);
                    break;
                case "Search":
                    try{
                        if(!this.vistitaPrincipal.txtFldSearchV.getText().isEmpty()){
                            int buscarG=Integer.parseInt(this.vistitaPrincipal.txtFldSearchV.getText());
                            if(this.grafo.buscarVertice(buscarG)==null){
                                JOptionPane.showMessageDialog(null,"No se encontró el vertice");
                            }else{
                                JOptionPane.showMessageDialog(null,"El vertice buscado es: "+grafo.buscarVertice(buscarG).getDato());
                            }
                        }else {
                        JOptionPane.showMessageDialog(null,"Favor de ingresar vertice");
                        }
                    }catch(Exception x){
                        JOptionPane.showMessageDialog(null, "No se ha podido buscar el vértice. \nIntente de nuevo más tarde.");
                    }
                    limpiar();
                    break;
                case "ShowVertice":
                    this.vistitaPrincipal.setVisible(false);
                    this.vistaTablitas.setVisible(true);
                    this.vistitaPrincipal.setTitle("Vértices");
                    this.vistitaPrincipal.pnlAddEdge.setVisible(false);
                    this.vistitaPrincipal.pnlAddV.setVisible(false);
                    this.vistitaPrincipal.pnlAddEdge.setVisible(false);
                    this.vistaTablitas.pnlV.setVisible(true);
                    this.vistaTablitas.pnlAL.setVisible(false);
                    this.grafo.actual=this.grafo.getInicio();
                    llenarVertice();
                    break;
                case "ShowAdjacencyList":
                    this.vistitaPrincipal.setVisible(false);
                    this.vistaTablitas.setVisible(true);
                    this.vistitaPrincipal.setTitle("Lista de adyacencia");
                    this.vistitaPrincipal.pnlAddEdge.setVisible(false);
                    this.vistitaPrincipal.pnlAddV.setVisible(false);
                    this.vistitaPrincipal.pnlAddEdge.setVisible(false);
                    this.vistaTablitas.pnlV.setVisible(false);
                    this.vistaTablitas.pnlAL.setVisible(true);
                    this.grafo.actual=this.grafo.getInicio();
                    llenarLista();
                    break;
                case "Home":
                    iniciar();
                    break;
                    
            }
        }catch(Exception x){
         JOptionPane.showMessageDialog(null, "Error, hay un problema. \nIntente de nuevo más tarde");
        }
    }
    @Override
    public void keyTyped(KeyEvent e) {
         char letrita = e.getKeyChar();
         if(Character.isAlphabetic(letrita)){
             e.consume();
             this.vistitaPrincipal.getToolkit().beep();
             JOptionPane.showMessageDialog(null, "Caracter inválido");
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
